import React from 'react'
import Search from '../../modules/search/Components/Search'

const Header = () => {
  return (
    <>

      
    </>
  )
}

export default Header