import React from 'react'
import SearchPage from './modules/search/pages/SearchPage.jsx'

const App = () => {
  return (
    <div>
      <SearchPage/>
      

    </div>
  )
}

export default App